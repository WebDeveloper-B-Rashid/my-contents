db.brands.aggregate([])

// Aggreegation Syntax  db.collectionName.aggregate
// ([{---Pipline----}])

// ([{---Stage1+Stage2+Stage3+Stage4----}])