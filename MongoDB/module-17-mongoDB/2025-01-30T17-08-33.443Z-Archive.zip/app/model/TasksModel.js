import mongoose from "mongoose";

const TaskSchema = new mongoose.Schema({


})


const TasksModel= mongoose.model("tasks",TaskSchema)
export default TasksModel